package com.proyecto_final.tienda_adso.controller;

import com.proyecto_final.tienda_adso.model.User;
import com.proyecto_final.tienda_adso.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserRepository repo;
    public UserController(UserRepository repo){ this.repo = repo; }

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User u){
        // en producción: validar y hashear contraseña
        User saved = repo.save(u);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> get(@PathVariable Integer id){
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}
