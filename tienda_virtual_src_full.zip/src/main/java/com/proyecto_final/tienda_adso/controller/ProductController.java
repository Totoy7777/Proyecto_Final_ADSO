package com.proyecto_final.tienda_adso.controller;

import com.proyecto_final.tienda_adso.model.Product;
import com.proyecto_final.tienda_adso.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductService service;
    public ProductController(ProductService service){ this.service = service; }

    @GetMapping
    public List<Product> all(){ return service.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Product> get(@PathVariable Integer id){
        Product p = service.findById(id);
        if(p==null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(p);
    }

    @PostMapping
    public ResponseEntity<Product> create(@RequestBody Product p){
        return ResponseEntity.ok(service.save(p));
    }
}
