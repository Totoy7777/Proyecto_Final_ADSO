package com.proyecto_final.tienda_adso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaAdsoApplication {
    public static void main(String[] args) {
        SpringApplication.run(TiendaAdsoApplication.class, args);
    }
}
