package com.proyecto_final.tienda_adso.service;

import com.proyecto_final.tienda_adso.model.Product;
import java.util.List;

public interface ProductService {
    List<Product> findAll();
    Product findById(Integer id);
    Product save(Product p);
}
