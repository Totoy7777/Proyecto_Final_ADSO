package com.proyecto_final.tienda_adso.service.impl;

import com.proyecto_final.tienda_adso.model.Product;
import com.proyecto_final.tienda_adso.repository.ProductRepository;
import com.proyecto_final.tienda_adso.service.ProductService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository repo;
    public ProductServiceImpl(ProductRepository repo){ this.repo = repo; }

    @Override public List<Product> findAll(){ return repo.findAll(); }
    @Override public Product findById(Integer id){ return repo.findById(id).orElse(null); }
    @Override public Product save(Product p){ return repo.save(p); }
}
