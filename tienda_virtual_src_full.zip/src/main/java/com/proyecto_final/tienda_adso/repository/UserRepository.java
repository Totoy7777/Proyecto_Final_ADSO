package com.proyecto_final.tienda_adso.repository;

import com.proyecto_final.tienda_adso.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
}
