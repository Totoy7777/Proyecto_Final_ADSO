package com.proyecto_final.tienda_adso.repository;

import com.proyecto_final.tienda_adso.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Integer> {
}
