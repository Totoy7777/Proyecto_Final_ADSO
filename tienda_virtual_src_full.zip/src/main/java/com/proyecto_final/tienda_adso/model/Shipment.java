package com.proyecto_final.tienda_adso.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "shipments")
public class Shipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "shipping_id")
    private Integer id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false, unique = true)
    private Order order;

    @Column(name = "direccion_envio", length = 255)
    private String direccionEnvio;

    @Column(name = "estado_envio", columnDefinition = "ENUM('LISTO','ENVIADO','ENTREGADO','DEVUELTO')")
    private String estadoEnvio = "LISTO";

    @Column(name = "fecha_envio")
    private LocalDateTime fechaEnvio;

    @Column(name = "tracking", length = 100)
    private String tracking;

    // getters/setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Order getOrder() { return order; }
    public void setOrder(Order order) { this.order = order; }
    public String getDireccionEnvio() { return direccionEnvio; }
    public void setDireccionEnvio(String direccionEnvio) { this.direccionEnvio = direccionEnvio; }
    public String getEstadoEnvio() { return estadoEnvio; }
    public void setEstadoEnvio(String estadoEnvio) { this.estadoEnvio = estadoEnvio; }
    public java.time.LocalDateTime getFechaEnvio() { return fechaEnvio; }
    public void setFechaEnvio(java.time.LocalDateTime fechaEnvio) { this.fechaEnvio = fechaEnvio; }
    public String getTracking() { return tracking; }
    public void setTracking(String tracking) { this.tracking = tracking; }
}
